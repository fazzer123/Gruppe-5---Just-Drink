﻿<script type="text/javascript">
    $(function () { // will trigger when the document is ready
        $('.datepicker').datepicker()}; //Initialise any date pickers
    });
</script>